config() {
  NEW="$1"
  OLD="$(dirname $NEW)/$(basename $NEW .new)"
  # If there's no config file by that name, mv it over:
  if [ ! -r $OLD ]; then
    mv $NEW $OLD
  elif [ "$(cat $OLD | md5sum)" = "$(cat $NEW | md5sum)" ]; then
    # toss the redundant copy
    rm $NEW
  fi
  # Otherwise, we leave the .new copy for the admin to consider...
}

# Keep same perms on rc.vboxdrv.new:
if [ -e etc/rc.d/rc.vboxdrv ]; then
  cp -a etc/rc.d/rc.vboxdrv etc/rc.d/rc.vboxdrv.new.incoming
  cat etc/rc.d/rc.vboxdrv.new > etc/rc.d/rc.vboxdrv.new.incoming
  mv etc/rc.d/rc.vboxdrv.new.incoming etc/rc.d/rc.vboxdrv.new
fi

# Keep same perms on rc.vboxballoonctrl-service.new:
if [ -e etc/rc.d/rc.vboxballoonctrl-service ]; then
  cp -a etc/rc.d/rc.vboxballoonctrl-service etc/rc.d/rc.vboxballoonctrl-service.new.incoming
  cat etc/rc.d/rc.vboxballoonctrl-service.new > etc/rc.d/rc.vboxballoonctrl-service.new.incoming
  mv etc/rc.d/rc.vboxballoonctrl-service.new.incoming etc/rc.d/rc.vboxballoonctrl-service.new
fi

# Keep same perms on rc.vboxautostart-service.new:
if [ -e etc/rc.d/rc.vboxautostart-service ]; then
  cp -a etc/rc.d/rc.vboxautostart-service etc/rc.d/rc.vboxautostart-service.new.incoming
  cat etc/rc.d/rc.vboxautostart-service.new > etc/rc.d/rc.vboxautostart-service.new.incoming
  mv etc/rc.d/rc.vboxautostart-service.new.incoming etc/rc.d/rc.vboxautostart-service.new
fi

# Keep same perms on rc.vboxweb-service.new:
if [ -e etc/rc.d/rc.vboxweb-service ]; then
  cp -a etc/rc.d/rc.vboxweb-service etc/rc.d/rc.vboxweb-service.new.incoming
  cat etc/rc.d/rc.vboxweb-service.new > etc/rc.d/rc.vboxweb-service.new.incoming
  mv etc/rc.d/rc.vboxweb-service.new.incoming etc/rc.d/rc.vboxweb-service.new
fi

# Prepare the new configuration files
config etc/vbox/vbox.cfg.new
config etc/default/virtualbox.new
config etc/rc.d/rc.vboxdrv.new
config etc/rc.d/rc.vboxballoonctrl-service.new
config etc/rc.d/rc.vboxautostart-service.new
config etc/rc.d/rc.vboxweb-service.new

if [ -x /usr/bin/update-desktop-database ]; then
  /usr/bin/update-desktop-database usr/share/applications >/dev/null 2>&1
fi

if [ -x /usr/bin/update-mime-database ]; then
  /usr/bin/update-mime-database usr/share/mime >/dev/null 2>&1
fi

if [ -e usr/share/icons/hicolor/icon-theme.cache ]; then
  if [ -x /usr/bin/gtk-update-icon-cache ]; then
    /usr/bin/gtk-update-icon-cache -f usr/share/icons/hicolor >/dev/null 2>&1
  fi
fi

# Create vboxusers group
if chroot . getent group vboxusers >/dev/null
then
  : vboxusers group already present
else
  GROUPOPT="-g 215"
  if chroot . groupadd $GROUPOPT vboxusers 2>/dev/null
  then
    : vboxusers group successfully added
  else
    chroot . groupadd vboxusers
  fi
fi

# Create vboxweb user
if chroot . getent passwd vboxweb >/dev/null
then
  : vboxweb user already present
else
  USEROPT="-g vboxusers -u 240 -d /var/lib/vboxweb"
  if chroot . useradd $USEROPT vboxweb 2>/dev/null
  then
    : vboxweb user successfully added
  else
    chroot . useradd vboxweb
  fi
fi

